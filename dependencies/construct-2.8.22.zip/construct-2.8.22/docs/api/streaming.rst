===============================
Core API: Streaming
===============================

.. autofunction:: construct.Pointer
.. autofunction:: construct.Peek
.. autofunction:: construct.Seek
.. autofunction:: construct.Tell
.. autofunction:: construct.Pass
.. autofunction:: construct.Terminated
.. autofunction:: construct.Restreamed
.. autofunction:: construct.Rebuffered
