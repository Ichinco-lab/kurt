========================
Core API: Bytes and bits
========================

.. autofunction:: construct.Bytes
.. autofunction:: construct.GreedyBytes
.. autofunction:: construct.Bitwise
.. autofunction:: construct.Bytewise
