===============================
Core API: Tunneling
===============================

.. autofunction:: construct.RawCopy
.. autofunction:: construct.ByteSwapped
.. autofunction:: construct.BitsSwapped
.. autofunction:: construct.Prefixed
.. autofunction:: construct.PrefixedArray
.. autofunction:: construct.Checksum
.. autofunction:: construct.Compressed
