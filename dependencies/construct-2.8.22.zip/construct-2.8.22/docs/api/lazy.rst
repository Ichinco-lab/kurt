===============================
Core API: Lazy equivalents
===============================

.. autofunction:: construct.LazyStruct
.. autofunction:: construct.LazySequence
.. autofunction:: construct.LazyRange
.. autofunction:: construct.OnDemand
.. autofunction:: construct.LazyBound
