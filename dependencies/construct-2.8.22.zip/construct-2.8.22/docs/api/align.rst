===============================
Core API: Alignment and Padding
===============================

.. autofunction:: construct.Padding
.. autofunction:: construct.Padded
.. autofunction:: construct.Aligned
.. autofunction:: construct.AlignedStruct
