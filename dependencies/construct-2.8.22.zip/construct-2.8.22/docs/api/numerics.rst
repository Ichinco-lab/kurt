========================
Core API: Integers and Floats
========================

.. autofunction:: construct.FormatField
.. autofunction:: construct.BytesInteger
.. autofunction:: construct.BitsInteger
.. autofunction:: construct.VarInt
