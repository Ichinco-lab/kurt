===================
Core API: Strings
===================

.. autofunction:: construct.setglobalstringencoding
.. autofunction:: construct.String
.. autofunction:: construct.PascalString
.. autofunction:: construct.CString
.. autofunction:: construct.GreedyString
