===============================
Core API: Structs and Sequences
===============================

.. autofunction:: construct.Struct
.. autofunction:: construct.Sequence
.. autofunction:: construct.Embedded
.. autofunction:: construct.AlignedStruct
.. autofunction:: construct.BitStruct
.. autofunction:: construct.EmbeddedBitStruct
