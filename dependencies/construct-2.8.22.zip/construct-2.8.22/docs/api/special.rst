===============================
Core API: Special
===============================

.. autofunction:: construct.Embedded
.. autofunction:: construct.Renamed
