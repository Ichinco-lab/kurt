==========================================
``construct.lib`` -- entire module
==========================================

.. automodule:: construct.lib
