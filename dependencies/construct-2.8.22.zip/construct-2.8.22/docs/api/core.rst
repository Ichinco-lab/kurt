==========================================
``construct.core`` -- entire module
==========================================

.. automodule:: construct.core
