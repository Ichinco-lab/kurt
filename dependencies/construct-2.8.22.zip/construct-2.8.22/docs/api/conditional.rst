===============================
Core API: Conditional
===============================

.. autofunction:: construct.Union
.. autofunction:: construct.Select
.. autofunction:: construct.Optional
.. autofunction:: construct.If
.. autofunction:: construct.IfThenElse
.. autofunction:: construct.Switch
.. autofunction:: construct.StopIf
