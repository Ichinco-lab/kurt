===============================
Core API: Miscellaneous
===============================

.. autofunction:: construct.Const
.. autofunction:: construct.Computed
.. autofunction:: construct.Rebuild
.. autofunction:: construct.Default
.. autofunction:: construct.Check
.. autofunction:: construct.Error
.. autofunction:: construct.FocusedSeq
.. autofunction:: construct.Numpy
.. autofunction:: construct.NamedTuple
